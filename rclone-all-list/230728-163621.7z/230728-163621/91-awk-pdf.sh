awk -F "pdf/" '{print "---"}' 01-y5ncmi-tradepub > 01-pdf
