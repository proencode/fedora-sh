awk -F "ebooks/tradepub/2022/" '{print "---"}' 01-y5ncmi-tradepub > 02-ebooks-tradepub-2022
