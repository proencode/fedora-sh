awk -F "ebooks/tradepub/2023/" '{print "---"}' 01-y5ncmi-tradepub > 03-ebooks-tradepub-2023
